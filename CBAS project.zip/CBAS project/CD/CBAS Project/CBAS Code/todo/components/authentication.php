<?php
    session_start();
    require 'dbconnect.php';
    $current_eid=$_SESSION['eid'];
?>