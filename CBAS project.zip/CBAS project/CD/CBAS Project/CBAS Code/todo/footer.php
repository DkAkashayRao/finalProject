<!-- footer content -->
 <footer  style="background-color: #2a3f54; color:white;padding-top: 10px;padding-bottom: 0px;bottom: 0px;left: 0px;right: 0px;margin-bottom: 0px;">
   <div class="pull-right">
     <a style="color:white; font-size:15px;" href="about/index.html">Developers </a>
   </div>
   <div class="clearfix"></div>
 </footer>
 <!-- /footer content -->
