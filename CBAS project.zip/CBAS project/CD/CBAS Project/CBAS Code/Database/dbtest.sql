-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2018 at 03:47 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `aid` int(11) NOT NULL,
  `date1` date NOT NULL,
  `time1` time NOT NULL,
  `ampm` varchar(5) NOT NULL DEFAULT 'am',
  `msg` varchar(500) NOT NULL,
  `eid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `eid` varchar(10) NOT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `uname` varchar(40) NOT NULL,
  `email` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL DEFAULT 'Male',
  `short_bio` longtext,
  `address` text,
  `s_ans_1` varchar(20) DEFAULT NULL,
  `s_ans_2` varchar(20) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `proj_mgr` tinyint(1) NOT NULL DEFAULT '0',
  `credits` float NOT NULL DEFAULT '0',
  `first_log` int(1) NOT NULL DEFAULT '0',
  `avatar_url` varchar(100) NOT NULL DEFAULT 'default.jpg',
  `vh_efficiency` float NOT NULL DEFAULT '0',
  `h_efficiency` float NOT NULL DEFAULT '0',
  `m_efficiency` float NOT NULL DEFAULT '0',
  `l_efficiency` float NOT NULL DEFAULT '0',
  `vl_efficiency` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`eid`, `ename`, `uname`, `email`, `password`, `phone`, `dob`, `gender`, `short_bio`, `address`, `s_ans_1`, `s_ans_2`, `admin`, `proj_mgr`, `credits`, `first_log`, `avatar_url`, `vh_efficiency`, `h_efficiency`, `m_efficiency`, `l_efficiency`, `vl_efficiency`) VALUES
('admin', 'admin', '', '', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', '', '0000-00-00', 'male', '', '', '', '', 1, 0, 0, 0, 'default.jpg', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `extras`
--

CREATE TABLE `extras` (
  `prim` int(1) NOT NULL,
  `cred_threshold` varchar(10) NOT NULL,
  `min_cred` varchar(10) NOT NULL,
  `p_very_hard` varchar(20) NOT NULL,
  `p_hard` varchar(10) NOT NULL,
  `p_med` varchar(10) NOT NULL,
  `p_low` varchar(10) NOT NULL,
  `p_very_low` varchar(20) NOT NULL,
  `s_very_hard` varchar(20) NOT NULL,
  `s_hard` varchar(10) NOT NULL,
  `s_med` varchar(10) NOT NULL,
  `s_low` varchar(10) NOT NULL,
  `s_very_low` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extras`
--

INSERT INTO `extras` (`prim`, `cred_threshold`, `min_cred`, `p_very_hard`, `p_hard`, `p_med`, `p_low`, `p_very_low`, `s_very_hard`, `s_hard`, `s_med`, `s_low`, `s_very_low`) VALUES
(1, '4', '1', '5000', '4000', '3000', '2000', '1000', '500', '400', '300', '200', '100');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `nid` int(11) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `message` varchar(10000) NOT NULL,
  `from1` varchar(20) NOT NULL,
  `to1` varchar(20) NOT NULL,
  `first` int(11) NOT NULL DEFAULT '1',
  `date1` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `pno` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `p_mgr_id` varchar(10) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `submitdate` date NOT NULL,
  `priority` text NOT NULL,
  `difficulty` varchar(20) NOT NULL DEFAULT 'very_low',
  `lender` varchar(50) NOT NULL,
  `remarks` text NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `description` varchar(1000) NOT NULL,
  `field` varchar(50) NOT NULL,
  `credits` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subtasks`
--

CREATE TABLE `subtasks` (
  `stid` int(11) NOT NULL,
  `pno` int(11) NOT NULL,
  `sno` int(11) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `eid` varchar(10) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `submitdate` date NOT NULL,
  `priority` text NOT NULL,
  `difficulty` varchar(20) NOT NULL DEFAULT 'very_low',
  `remarks` text NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `description` varchar(1000) NOT NULL,
  `credits` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE `upload` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `stid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `ff` (`eid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`eid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `extras`
--
ALTER TABLE `extras`
  ADD PRIMARY KEY (`prim`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`pno`),
  ADD KEY `p_mgr_id` (`p_mgr_id`);

--
-- Indexes for table `subtasks`
--
ALTER TABLE `subtasks`
  ADD PRIMARY KEY (`stid`),
  ADD KEY `pno` (`pno`),
  ADD KEY `eid` (`eid`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `extras`
--
ALTER TABLE `extras`
  MODIFY `prim` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `pno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subtasks`
--
ALTER TABLE `subtasks`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `ff` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`p_mgr_id`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subtasks`
--
ALTER TABLE `subtasks`
  ADD CONSTRAINT `subtasks_ibfk_1` FOREIGN KEY (`pno`) REFERENCES `projects` (`pno`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subtasks_ibfk_2` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
