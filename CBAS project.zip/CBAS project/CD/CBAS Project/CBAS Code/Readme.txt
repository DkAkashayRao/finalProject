Read the instructions before running the code.

System requirements for running the code:
1. XAMPP v3.2.2 recommended.
2. Google Chrome or Mozilla Firefox Web Browser.
Note: The project is built using xampp v3.2.2 and the experiance of the web pages may change if any other versions of xampp are used.

Steps to run the code:
1. Copy the folder "todo" to C:\xampp\htdocs\
2. Run the apache server and MySQL from the XAMPP control Panel.
3. Open http://localhost/phpmyadmin/ in the web browser.
4. create database 'dbtest'.
5. Import the database 'dbtest.sql' from 'todo' folder by clicking import option in the phpmyadmin.
6. goto localhost/todo/index.php in the web browser to execute the code.

Login Credentials are:
1. Admin
	username: admin 
	password: admin
Admin can add Project Manager and Employee by logging into the system portal.
